
public class MineSweeper {

	public static void main(String[] args) {
		
		new ConfigWindow();
	}
}
